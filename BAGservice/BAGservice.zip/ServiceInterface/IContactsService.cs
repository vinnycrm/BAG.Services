﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using BAG.DataInterface;
using BAG.Dataobject;
using System.Text;

namespace BAGservice.ServiceInterface
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IContacts" in both code and config file together.
    [ServiceContract]
    public interface IContacts
    {
        [OperationContract]
        [WebInvoke(Method = "POST",
            RequestFormat = WebMessageFormat.Json,
            ResponseFormat = WebMessageFormat.Json,
            UriTemplate = "ImportContacts"
            )]
        string ImportContacts(GoogleContacts[] userdetails);

        [OperationContract]
        [WebGet(
            RequestFormat = WebMessageFormat.Json,
            ResponseFormat = WebMessageFormat.Json,
            UriTemplate = "GetUserContact/{Id}")]

        GoogleContacts[] GetContactDetails(string Id);
    }
}
