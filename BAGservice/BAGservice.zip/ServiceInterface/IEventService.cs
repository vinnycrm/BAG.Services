﻿using System.ServiceModel;
using System.ServiceModel.Web;
using BAG.DataInterface;
using BAG.Dataobject;
using System.Collections.Generic;

namespace BAGservice.ServiceInterface
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IEventService" in both code and config file together.
    [ServiceContract]
    public interface IEventService
    {
        [OperationContract]
        [WebGet(
            RequestFormat = WebMessageFormat.Json,
            ResponseFormat = WebMessageFormat.Json,
            UriTemplate = "GETEventTypes")]

        EventTypes[] GETEventTypes();

        [OperationContract]
        [WebInvoke(Method = "POST",
            RequestFormat = WebMessageFormat.Json,
            ResponseFormat = WebMessageFormat.Json,
            UriTemplate = "CreateEvent"
            )]
        string CreateEvent(CreateEvent obj);

        [OperationContract]
        [WebGet(
            RequestFormat = WebMessageFormat.Json,
            ResponseFormat = WebMessageFormat.Json,
            UriTemplate = "GETHeaderEvent/{Id}")]

        Group_HeaderEvent GETHeaderEvent(string Id);

        [OperationContract]
        [WebGet(
            RequestFormat = WebMessageFormat.Json,
            ResponseFormat = WebMessageFormat.Json,
            UriTemplate = "GETEventDetails/{Id}")]

        EventDetails GETEventDetails(string Id);

    }
}
