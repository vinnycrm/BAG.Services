﻿using BAGservice.ServiceInterface;
using BAG.DataInterface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.Text;
using BAG.Account.Dataaccess;
using BAG.Dataobject;

namespace BAGservice.Services
{
    [AspNetCompatibilityRequirements(RequirementsMode
        = AspNetCompatibilityRequirementsMode.Allowed)]
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "AccountService" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select AccountService.svc or AccountService.svc.cs at the Solution Explorer and start debugging.
    public class AccountService : IAccountService
    {
        
        public string AddMembers(Registration obj)
        {
            try
            {
                U_USR_LgnDAL ologonDAL = new U_USR_LgnDAL();
                U_USR_MASTERDAL oMstDAL = new U_USR_MASTERDAL();
                U_USR_Lgn Lgnobj = new U_USR_Lgn();
                U_USR_MASTER Mstobj = new U_USR_MASTER();
                if (string.IsNullOrEmpty(ologonDAL.CheckEmail_Exist(obj.Email_Id)))
                {
                    Mstobj.Usr_Id = Guid.NewGuid().ToString();
                    Mstobj.Usr_role_Id = "";
                    Mstobj.Date_Of_Birth = DateTime.Now;
                    Mstobj.First_Name = obj.First_Name;
                    Mstobj.Alt_Email_Id = string.Empty;
                    Mstobj.Gender = string.Empty;
                    Mstobj.Is_married = 0;
                    Mstobj.Last_Name = string.Empty;
                    Mstobj.Media_Id_Img = "1";
                    Mstobj.Address_Id = "1";
                    Mstobj.Rating = string.Empty;
                    Mstobj.Updated_by = string.Empty;
                    Mstobj.Updated_Date = DateTime.Now;
                    Mstobj.Wed_anniversary = DateTime.Now;
                    Mstobj.About_member = string.Empty;
                    Mstobj.Created_by = string.Empty;
                    Mstobj.Created_Date = DateTime.Now;
                    var status = oMstDAL.InsertU_USR_MASTER(Mstobj);
                    if (status)
                    {
                        Lgnobj.Login_Id = Guid.NewGuid().ToString();
                        Lgnobj.Login_status = 0;
                        Lgnobj.Email_ID = obj.Email_Id;
                        Lgnobj.Mobile_Number = obj.Phone_No;
                        Lgnobj.Pwd = obj.Password;
                        Lgnobj.Created_by = string.Empty;
                        Lgnobj.Updated_by = string.Empty;
                        Lgnobj.Updated_Date = DateTime.Now;
                        Lgnobj.Created_Date = DateTime.Now;
                        Lgnobj.Last_Login_Date = DateTime.Now;
                        Lgnobj.Ip_Address = string.Empty;
                        Lgnobj.Usr_Mst_Id = Mstobj.Usr_Id;
                        status = ologonDAL.InsertU_USR_Lgn(Lgnobj);
                    }
                    if(status==true)
                    {
                        return "1";
                    }
                    else
                    {
                        return "0"; // 0 indicates unsuccessfull
                    }
                }
                else
                {
                    return "2";  // 2 indicates email id already exists
                }
            }
            catch
            {
                return "0"; // 0 indicates unsuccessfull
            }
        }

        public Login AddMembers_ThirdParty(SocialRegistration obj)
        {
            try
            {
                U_USR_LgnDAL ologonDAL = new U_USR_LgnDAL();
                U_USR_MASTERDAL oMstDAL = new U_USR_MASTERDAL();
                U_USR_Lgn Lgnobj = new U_USR_Lgn();
                U_USR_MASTER Mstobj = new U_USR_MASTER();
                string user_id = ologonDAL.CheckLoginId_Exist(obj.Id);
                if (string.IsNullOrEmpty(user_id))
                {
                    Mstobj.Usr_Id = Guid.NewGuid().ToString();
                    Mstobj.Usr_role_Id = "";
                    Mstobj.Date_Of_Birth = DateTime.Now;
                    Mstobj.First_Name = obj.First_Name;
                    Mstobj.Alt_Email_Id = string.Empty;
                    Mstobj.Gender = string.Empty;
                    Mstobj.Is_married = 0;
                    Mstobj.Last_Name = string.Empty;
                    Mstobj.Media_Id_Img = "1";
                    Mstobj.Address_Id = "1";
                    Mstobj.Rating = string.Empty;
                    Mstobj.Updated_by = string.Empty;
                    Mstobj.Updated_Date = DateTime.Now;
                    Mstobj.Wed_anniversary = DateTime.Now;
                    Mstobj.About_member = string.Empty;
                    Mstobj.Created_by = string.Empty;
                    Mstobj.Created_Date = DateTime.Now;
                    var status = oMstDAL.InsertU_USR_MASTER(Mstobj);
                    if (status)
                    {
                        Lgnobj.Login_Id = obj.Id;
                        Lgnobj.Login_status = 2;
                        Lgnobj.Email_ID = obj.Email_Id;
                        Lgnobj.Mobile_Number = obj.Phone_No;
                        Lgnobj.Pwd = string.Empty;
                        Lgnobj.Created_by = string.Empty;
                        Lgnobj.Updated_by = string.Empty;
                        Lgnobj.Updated_Date = DateTime.Now;
                        Lgnobj.Created_Date = DateTime.Now;
                        Lgnobj.Last_Login_Date = DateTime.Now;
                        Lgnobj.Ip_Address = string.Empty;
                        Lgnobj.Usr_Mst_Id = Mstobj.Usr_Id;
                        status = ologonDAL.InsertU_USR_Lgn(Lgnobj);
                    }
                    if (status == true)
                    {
                        Login ologin = new Login();
                        user_id= ologonDAL.CheckLoginId_Exist(obj.Id);
                        ologin.First_Name = obj.First_Name;
                        ologin.Id = user_id;
                        return ologin;
                    }
                    else
                    {
                        return null;  //  indicates unsuccessfull
                    }
                }
                else
                {
                    Login ologin = new Login();
                    ologin.First_Name = obj.First_Name;
                    ologin.Id = user_id;
                    return ologin;   //  indicates LoginId already exists
                }
            }
            catch
            {
                return null; //  indicates unsuccessfull
            }
        }


        public Login GetMemberDetails(string EmailId, string password)
        {
            U_USR_LgnDAL olgnDAL = new U_USR_LgnDAL();
            return olgnDAL.GetLoginDetails(EmailId, password); 
        }

        public string ActivateMember(string member_id)
        {
            try
            {
                U_USR_LgnDAL olgnDAL = new U_USR_LgnDAL();
                olgnDAL.ActivateMember(member_id);
                return "1";
            }
            catch
            {
                return "0";
            }
        }

        public string GetAllMemberDetails()
        {
            return null;
        }

        public string UpdateMemberDetails(string omember)
        {
            return null;
        }

        public string GetMemberDetails(string id)
        {
            return null;
        }
    }
}
