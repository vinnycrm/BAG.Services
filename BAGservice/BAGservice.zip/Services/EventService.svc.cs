﻿using System;
using System.Linq;
using BAGservice.ServiceInterface;
using BAG.Dataobject;
using BAG.Event.Dataaccess;
using System.ServiceModel.Activation;
using System.Collections.Generic;

namespace BAGservice.Services
{
    [AspNetCompatibilityRequirements(RequirementsMode
        = AspNetCompatibilityRequirementsMode.Allowed)]
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "EventService" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select EventService.svc or EventService.svc.cs at the Solution Explorer and start debugging.
    public class EventService : IEventService
    {
        public EventTypes[] GETEventTypes()
        {
             U_ADM_EVNT_TypeDAL oeventDAL = new U_ADM_EVNT_TypeDAL();
            return oeventDAL.Select_EVENT_Types();
        }

        public string CreateEvent(CreateEvent obj)
        {
            U_EVNT_MASTERDAL oeventDAL = new U_EVNT_MASTERDAL();
            U_EVNT_MASTER oevent = new U_EVNT_MASTER();
            oevent.Event_Creator_Id = obj.User_Id;
            oevent.COMMENTS = "";
            oevent.Created_by = obj.User_Id;
            oevent.Created_Date = DateTime.Now;
            oevent.Event_Desc = obj.Description;
            oevent.Event_EndDate = obj.End_Date;
            oevent.Event_Id = Guid.NewGuid().ToString();
            oevent.Event_StartDate = obj.Start_Date;
            oevent.Event_Name = obj.Event_Name;
            oevent.Event_Status = "1";
            oevent.Event_Type_Id = obj.Type_Id;
            oevent.Even_Location = obj.Event_Location;
            oevent.Media_Id_Img = "1";
            oevent.Updated_by = "";
            oevent.Updated_Date = DateTime.Now;
            var status= oeventDAL.InsertU_EVNT_MASTER(oevent);
            if (status == true)
                return "1";
            else
                return "0";
        }

        public Group_HeaderEvent GETHeaderEvent(string Id)
        {
            U_EVNT_MASTERDAL oeventDAL = new U_EVNT_MASTERDAL();
            return oeventDAL.Get_HeaderEvents(Id);
        }

        public EventDetails GETEventDetails(string Id)
        {
            U_EVNT_MASTERDAL oeventDAL = new U_EVNT_MASTERDAL();
            return oeventDAL.Get_EventsDetails(Id);
        }
    }
}
