﻿using BAGservice.ServiceInterface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel.Activation;
using System.Text;
using BAG.Dataobject;
using BAG.Contacts.Dataaccess;
using System.Web;
using System.IO;

namespace BAGservice.Services
{
    [AspNetCompatibilityRequirements(RequirementsMode
        = AspNetCompatibilityRequirementsMode.Allowed)]
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Contacts" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Contacts.svc or Contacts.svc.cs at the Solution Explorer and start debugging.
    public class Contacts : IContacts
    {
        public string ImportContacts(GoogleContacts[] obj)
        {
            try
            {
                WriteErrorLog("Imp Start");
                U_USR_ContactsDAL ocontactsDAL = new U_USR_ContactsDAL();
                U_USR_Map_ContactDAL omapcntsDAL = new U_USR_Map_ContactDAL();
                foreach (var item in obj)
                {
                    if (string.IsNullOrEmpty(ocontactsDAL.CheckContact_Exist(item.EmailID)))
                    {
                        WriteErrorLog("if");
                        U_USR_Contacts ocontacts = new U_USR_Contacts();
                        ocontacts.Contact_Id = Guid.NewGuid().ToString();
                        ocontacts.Contact_Source = "Google";
                        ocontacts.Contact_Status = "1";
                        ocontacts.Created_by = "";
                        ocontacts.Created_Date = DateTime.Now;
                        ocontacts.Email_Id = item.EmailID;
                        ocontacts.Mobile_Number = "";
                        ocontacts.Person_Name = "";
                        ocontacts.Updated_by = "";
                        ocontacts.Updated_Date = DateTime.Now;
                        ocontactsDAL.InsertU_USR_Contacts(ocontacts);
                    }

                }
                foreach (var item in obj)
                {
                    string contactId = ocontactsDAL.CheckContact_Exist(item.EmailID);
                    string mapingId = omapcntsDAL.CheckMaping_Exist(item.UserId,contactId);
                    if (!string.IsNullOrEmpty(contactId) & string.IsNullOrEmpty(mapingId))
                    {
                        WriteErrorLog("item");
                        U_USR_Map_Contact ocontacts = new U_USR_Map_Contact();
                        ocontacts.Id = Guid.NewGuid().ToString();
                        ocontacts.Contact_Id = contactId;
                        ocontacts.Usr_Id = item.UserId;
                        ocontacts.Comments = "";
                        ocontacts.Created_by = "";
                        ocontacts.Created_Date = DateTime.Now;
                        ocontacts.Updated_by = "";
                        ocontacts.Updated_Date = DateTime.Now;
                        bool status=  omapcntsDAL.InsertU_USR_Map_Contact(ocontacts);
                        WriteErrorLog(status.ToString());
                    }

                }
                return "1"; // 1 successfull
            }
            catch (Exception ex)
            {
                WriteErrorLog(ex.ToString());
                return "0"; // 0 indicates unsuccessfull
            }
        }

        public GoogleContacts[] GetContactDetails(string id)
        {
            try
            {
                U_USR_ContactsDAL ocontactsDAL = new U_USR_ContactsDAL();
                return ocontactsDAL.GetUser_Contacts(id);
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public static void WriteErrorLog(string _Error)
        {
            try
            {
                string _Path = HttpContext.Current.Server.MapPath("/Logs/");
                if (!Directory.Exists(_Path))
                    Directory.CreateDirectory(_Path);
                ErrorXml x = new ErrorXml();
                x.Error = _Error;
                x.Details = "";
                x.Comments = "";
                x.Function = new System.Diagnostics.StackTrace().GetFrame(1).GetMethod().Name.ToString();
                StreamWriter _STW = new StreamWriter(_Path + DateTime.Today.ToString("ddMMyyyy") + ".log", true);
                _STW.WriteLine(x.GetSerializedText());
                _STW.Flush();
                _STW.Dispose();
            }
            catch { }
        }

        public class ErrorXml
        {
            public string Error, Details, Comments, Function, Path, IPAddress, BrowserType, BrowserName, BrowserVersion, ErrorTime;
            public string GetSerializedText()
            {
                StringWriter _SW = new StringWriter();
                _SW.WriteLine(" ------------------------- " + DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss tt") + " -------------------------");
                _SW.WriteLine("Error            : " + Error);
                _SW.WriteLine("Details          : " + Details);
                _SW.WriteLine("Comments         : " + Comments);
                _SW.WriteLine("Function         : " + Function);
                _SW.WriteLine("Path             : " + HttpContext.Current.Request.Path);
                _SW.WriteLine("IP Address       : " + System.Net.Dns.GetHostAddresses(System.Net.Dns.GetHostName()).GetValue(0).ToString());
                _SW.WriteLine("Browser Type     : " + HttpContext.Current.Request.Browser.Type.ToString());
                _SW.WriteLine("Browser Name     : " + HttpContext.Current.Request.Browser.Browser.ToString());
                _SW.WriteLine("Browser Version  : " + HttpContext.Current.Request.Browser.Version.ToString());
                _SW.WriteLine(" ------------------------- End -------------------------");
                string a = _SW.ToString();
                _SW.Close();
                _SW.Dispose();
                return a;
            }
        }
    }
}
